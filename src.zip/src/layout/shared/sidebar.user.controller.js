(function() {
	'use strict';
	angular
		.module('TADkit')
		.controller('SidebarUserController', SidebarUserController);

	function SidebarUserController ($scope){

		// // User Profile
		// $scope.user = function(user) {
		// 	$scope.user.profile = Settings.getProfile(user);
		// };

	}
})();