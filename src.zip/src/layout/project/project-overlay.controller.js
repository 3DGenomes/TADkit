(function() {
	'use strict';
	angular
		.module('TADkit')
		.controller('ProjectOverlayController', ProjectOverlayController);

	function ProjectOverlayController($scope) {

	}
})();