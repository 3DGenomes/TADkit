(function() {
	'use strict';
	angular
		.module('TADkit')
		.controller('ProjectContentController', ProjectContentController);

	function ProjectContentController($scope) {


	}
})();