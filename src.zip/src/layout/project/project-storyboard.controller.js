(function() {
	'use strict';
	angular
		.module('TADkit')
		.controller('ProjectStoryboardController', ProjectStoryboardController);

	function ProjectStoryboardController($scope) {

	}
})();