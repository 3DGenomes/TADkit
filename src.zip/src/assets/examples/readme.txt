Place TADbit JSON and associated TSV files here to allow URL access via:
eg. tadkit/index.html#/project/loader/chr2L_5_106.json will load the file
    and also load the assocaited chr2L_5_106.tsv if in the same folder. 
